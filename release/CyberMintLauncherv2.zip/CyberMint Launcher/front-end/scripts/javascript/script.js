"use strict";

document.addEventListener("DOMContentLoaded", ()=>{
  
    Controller.load();

});
